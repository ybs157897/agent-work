import React from 'react';
import { useTasksStore, Task } from '../stores/tasks.store';
import { LayoutShell } from '@components/layout-shell';
import { KanbanSquare, List, ChevronDown, Plus } from 'lucide-react';

export default function TasksPage() {
  const tasks = useTasksStore(s => s.tasks);
  const viewMode = useTasksStore(s => s.viewMode);
  const setViewMode = useTasksStore(s => s.setViewMode);

  const columns = [
    { id: 'todo', title: '待办', tasks: tasks.filter(t => t.status === 'todo') },
    { id: 'inProgress', title: '进行中', tasks: tasks.filter(t => t.status === 'inProgress') },
    { id: 'completed', title: '完成', tasks: tasks.filter(t => t.status === 'completed') },
    { id: 'blocked', title: '阻塞', tasks: tasks.filter(t => t.status === 'blocked') },
  ];

  return (
    <LayoutShell breadcrumb="任务看板" activeNav="tasks">
      <div className="layout-safe h-full flex flex-col py-comfortable">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-stack-md shrink-0">
          <div className="flex items-center gap-comfortable">
            <h2 className="text-h2 text-text-primary tracking-tight">任务看板</h2>
            
            <div className="flex bg-surface-base rounded-button p-1 border border-border-subtle">
              <button 
                onClick={() => setViewMode('kanban')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm text-body font-medium transition-colors ${viewMode === 'kanban' ? 'bg-white shadow-sm text-text-primary' : 'text-text-secondary hover:text-text-primary'}`}
              >
                <KanbanSquare className="w-4 h-4" />
                看板
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm text-body font-medium transition-colors ${viewMode === 'list' ? 'bg-white shadow-sm text-text-primary' : 'text-text-secondary hover:text-text-primary'}`}
              >
                <List className="w-4 h-4" />
                列表
              </button>
            </div>
          </div>

          <div className="flex items-center gap-snug">
            <span className="text-body text-text-secondary">筛选</span>
            <button className="flex items-center gap-1 px-3 py-1.5 bg-surface-raised border border-border-subtle rounded-button text-body text-text-primary hover:bg-surface-base transition-colors">
              优先级 <ChevronDown className="w-4 h-4 text-text-tertiary" />
            </button>
            <button className="flex items-center gap-1 px-3 py-1.5 bg-surface-raised border border-border-subtle rounded-button text-body text-text-primary hover:bg-surface-base transition-colors">
              指派人 <ChevronDown className="w-4 h-4 text-text-tertiary" />
            </button>
          </div>
        </div>

        {/* Board or List View */}
        <div className="flex-1 min-h-0 overflow-x-auto pb-6">
          {viewMode === 'kanban' ? (
            <div className="flex gap-4 h-full min-w-max">
              {columns.map(col => (
                <KanbanColumn key={col.id} id={col.id} title={col.title} tasks={col.tasks} />
              ))}
            </div>
          ) : (
            <div className="bg-surface-raised rounded-xl shadow-level-1 border border-border-subtle p-comfortable h-full overflow-y-auto">
               <div className="space-y-stack-md">
                 {columns.map(col => (
                    <div key={col.id}>
                      <h3 className="font-semibold text-body-lg text-text-primary mb-4 flex items-center gap-2">
                        {col.title} <span className="text-text-tertiary text-body font-normal tabular-nums">{col.tasks.length}</span>
                      </h3>
                      <div className="space-y-2">
                        {col.tasks.map(task => (
                           <div key={task.id} className="flex items-center justify-between p-3 border border-border-subtle rounded-lg hover:bg-surface-base transition-colors">
                              <div className="flex items-center gap-4">
                                <PriorityBadge priority={task.priority} />
                                <span className={`font-medium text-sm ${task.status === 'completed' ? 'line-through opacity-60' : 'text-text-primary'}`}>{task.title}</span>
                              </div>
                              <div className="flex items-center gap-6">
                                {task.agentName && (
                                   <div className="flex items-center gap-1.5 w-32 shrink-0">
                                      <img src={task.agentAvatar!} alt={task.agentName} className="w-5 h-5 rounded-full object-cover" />
                                      <span className="text-xs text-text-secondary truncate">{task.agentName}</span>
                                   </div>
                                )}
                                <span className="text-xs text-text-tertiary tabular-nums w-12 text-right">{task.dueDate}</span>
                              </div>
                           </div>
                        ))}
                        {col.tasks.length === 0 && <div className="text-caption text-text-tertiary py-2">暂无任务</div>}
                      </div>
                    </div>
                 ))}
               </div>
            </div>
          )}
        </div>

      </div>
    </LayoutShell>
  );
}

function KanbanColumn({ id, title, tasks }: { id: string, title: string, tasks: Task[] }) {
  const isInProgress = id === 'inProgress';
  
  return (
    <div className={`w-[320px] shrink-0 flex flex-col rounded-xl ${isInProgress ? 'bg-brand-primary/5 ring-1 ring-brand-primary/20' : 'bg-surface-warm'}`}>
      <div className="p-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-body-lg text-text-primary">{title}</h3>
          <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full bg-surface-raised border border-border-subtle text-caption font-medium text-text-secondary tabular-nums">
            {tasks.length}
          </span>
        </div>
        <button className="p-1 hover:bg-surface-base rounded text-text-tertiary hover:text-text-primary transition-colors">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-3">
        {tasks.map(task => (
          <TaskCard key={task.id} task={task} />
        ))}
      </div>
    </div>
  );
}

function TaskCard({ task }: { task: Task }) {
  const isCompleted = task.status === 'completed';
  const isBlocked = task.status === 'blocked';
  
  let bgClass = "bg-surface-raised";
  if (isBlocked) {
    if (task.blockedReason?.includes('权限')) bgClass = "bg-status-error/10 border-status-error/20";
    else bgClass = "bg-status-warning/10 border-status-warning/20";
  }

  return (
    <div className={`rounded-lg p-3 shadow-card border border-border-subtle cursor-pointer transition-all duration-200 hover:-translate-y-[2px] hover:shadow-level-2 ${bgClass}`}>
      <h4 className={`font-medium text-sm text-text-primary mb-3 leading-snug ${isCompleted ? 'line-through opacity-60' : ''}`}>
        {task.title}
      </h4>
      
      {task.agentName ? (
        <div className="flex items-center gap-1.5 mb-3">
          <img src={task.agentAvatar!} alt={task.agentName} className="w-5 h-5 rounded-full object-cover" />
          <span className="text-xs font-medium text-text-secondary">{task.agentName}</span>
        </div>
      ) : (
        <div className="flex items-center gap-1.5 mb-3">
          <div className="w-5 h-5 rounded-full border border-dashed border-border-strong flex items-center justify-center bg-surface-base">
            <span className="text-[10px] text-text-tertiary">?</span>
          </div>
          <span className="text-xs text-text-tertiary">无 Agent</span>
        </div>
      )}

      {isBlocked && task.blockedReason && (
        <div className="text-xs font-medium text-status-error mb-3">{task.blockedReason}</div>
      )}

      <div className="flex items-center justify-between mt-auto">
        <PriorityBadge priority={task.priority} />
        <span className="text-xs text-text-tertiary tabular-nums">{task.dueDate}</span>
      </div>
    </div>
  );
}

function PriorityBadge({ priority }: { priority: string }) {
  let color = 'bg-brand-primary';
  let label = '低优';
  
  if (priority === 'high') { color = 'bg-status-error'; label = '高优'; }
  if (priority === 'medium') { color = 'bg-status-warning'; label = '中优'; }

  return (
    <div className="flex items-center gap-1.5">
      <div className={`w-2 h-2 rounded-full ${color}`} />
      <span className="text-xs text-text-secondary">{label}</span>
    </div>
  );
}