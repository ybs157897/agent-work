import React from 'react';
import { LayoutDashboard, Bot, KanbanSquare, ScrollText, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface LayoutShellProps {
  children: React.ReactNode;
  breadcrumb: string;
  activeNav: string;
}

export function LayoutShell({ children, breadcrumb, activeNav }: LayoutShellProps) {
  const navigate = (pageId: string) => {
    // @ts-ignore - window.App is injected by orchestrator
    if (window.App?.transitionTo) window.App.transitionTo(pageId);
  };

  return (
    <div className="flex h-screen w-full bg-surface-base overflow-hidden">
      
      {/* Sidebar */}
      <aside className="w-[60px] shrink-0 h-full bg-surface-raised border-r border-border-subtle flex flex-col items-center py-4 z-20 relative">
        <div className="w-8 h-8 bg-brand-primary rounded mb-8 flex items-center justify-center text-white font-bold text-lg shadow-sm">
          A
        </div>
        
        <nav className="flex flex-col gap-2 flex-1 w-full px-2">
          <NavItem icon={<LayoutDashboard />} label="总览" isActive={activeNav === 'dashboard'} onClick={() => navigate('index')} />
          <NavItem icon={<Bot />} label="智能体团队" isActive={activeNav === 'agents'} onClick={() => navigate('agents')} />
          <NavItem icon={<KanbanSquare />} label="任务看板" isActive={activeNav === 'tasks'} onClick={() => navigate('tasks')} />
          <NavItem icon={<ScrollText />} label="日志" isActive={activeNav === 'logs'} onClick={() => {}} />
          <NavItem icon={<Settings />} label="设置" isActive={activeNav === 'settings'} onClick={() => {}} />
        </nav>

        <div className="mt-auto pt-4">
          <img 
            src="https://images.unsplash.com/photo-1767500263347-4eef1b448fc2?q=80&w=200" 
            alt="User" 
            className="w-8 h-8 rounded-full object-cover ring-2 ring-transparent hover:ring-border-strong cursor-pointer transition-all"
          />
        </div>
      </aside>

      {/* Main Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top bar */}
        <header className="h-[48px] shrink-0 px-6 flex items-center justify-between border-b border-border-subtle bg-surface-base z-10 sticky top-0">
          <div className="flex items-center text-body font-medium">
            <span className="text-text-secondary cursor-pointer hover:text-text-primary">Team Space</span>
            <span className="mx-2 text-text-tertiary">/</span>
            <span className="text-text-primary">{breadcrumb}</span>
          </div>
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-status-success status-pulse"></div>
             <span className="text-caption text-text-secondary">System Online</span>
          </div>
        </header>

        {/* Content area with simple fade transition simulation */}
        <main className="flex-1 overflow-y-auto relative isolate h-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={breadcrumb}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="min-h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

    </div>
  );
}

function NavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick?: () => void }) {
  return (
    <div className="relative group w-full flex justify-center">
      <button 
        onClick={onClick}
        className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors duration-200 ${
          isActive 
            ? 'bg-brand-primary text-white shadow-level-1' 
            : 'text-text-secondary hover:bg-surface-base hover:text-text-primary'
        }`}
      >
        {React.cloneElement(icon as React.ReactElement, { className: "w-5 h-5" })}
      </button>
      
      {/* Tooltip */}
      <div className="absolute left-[60px] top-1/2 -translate-y-1/2 px-2 py-1 bg-surface-glass-dark text-text-inverse text-caption rounded opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all whitespace-nowrap z-50 pointer-events-none">
        {label}
      </div>
    </div>
  );
}