import React from 'react';
import { useAgentsStore, Agent } from '../stores/agents.store';
import { LayoutShell } from '@components/layout-shell';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X } from 'lucide-react';

export default function AgentsPage() {
  const agents = useAgentsStore(s => s.agents);
  const selectedAgentId = useAgentsStore(s => s.selectedAgentId);
  const selectAgent = useAgentsStore(s => s.selectAgent);
  const toggleAgentStatus = useAgentsStore(s => s.toggleAgentStatus);

  return (
    <LayoutShell breadcrumb="智能体团队" activeNav="agents">
      <div className="layout-safe space-y-stack-md py-comfortable relative">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-h2 text-text-primary tracking-tight">智能体团队</h2>
          <button className="flex items-center gap-1.5 bg-transparent border border-brand-primary text-brand-primary rounded-button px-base py-tight font-medium transition-colors duration-150 hover:bg-brand-primary/5 active:scale-[0.98]">
            <Plus className="w-4 h-4" />
            <span>添加 Agent</span>
          </button>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-comfortable pb-24">
          {agents.map((agent, index) => {
            const isWide = index === 1; // Second card spans 2 cols
            return (
              <AgentCard 
                key={agent.id} 
                agent={agent} 
                onClick={() => selectAgent(agent.id)}
                className={isWide ? "md:col-span-2 lg:col-span-2" : "col-span-1"}
              />
            );
          })}
        </div>

      </div>

      {/* Detail Panel Overlay */}
      <AnimatePresence>
        {selectedAgentId && (
          <DetailPanel 
            agent={agents.find(a => a.id === selectedAgentId)!} 
            onClose={() => selectAgent(null)}
            onToggleStatus={() => toggleAgentStatus(selectedAgentId)}
          />
        )}
      </AnimatePresence>
    </LayoutShell>
  );
}

function AgentCard({ agent, onClick, className = '' }: { agent: Agent, onClick: () => void, className?: string }) {
  return (
    <div 
      onClick={onClick}
      className={`bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable cursor-pointer transition-all duration-250 ease-out hover:-translate-y-[3px] hover:shadow-level-2 group flex flex-col ${className}`}
    >
      <div className="flex items-center gap-snug mb-comfortable">
        <img src={agent.avatar} alt={agent.name} className="w-12 h-12 rounded-full object-cover shrink-0 ring-2 ring-white shadow-sm" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-body-lg text-text-primary truncate">{agent.name}</h3>
            <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-caption font-medium bg-surface-base text-text-secondary border border-border-subtle">
              {agent.role}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 mb-snug">
        <StatusIndicator status={agent.status} />
        <span className="text-body text-text-primary font-medium">{getStatusText(agent.status)}</span>
      </div>

      <p className="text-caption text-text-secondary truncate mb-comfortable flex-1">
        {agent.task}
      </p>

      <div className="space-y-1 mb-comfortable">
        <div className="flex justify-end">
          <span className="text-caption text-text-tertiary tabular-nums">{agent.progress}%</span>
        </div>
        <div className="h-1 bg-surface-base rounded-full overflow-hidden">
          <div 
            className={`h-full ${agent.status === 'error' ? 'bg-status-error' : 'bg-brand-primary'} transition-all duration-500`} 
            style={{ width: `${agent.progress}%` }} 
          />
        </div>
      </div>

      <div className="pt-snug border-t border-border-subtle">
        <span className="text-caption font-medium text-brand-primary group-hover:text-brand-accent transition-colors">
          查看详情 →
        </span>
      </div>
    </div>
  );
}

function DetailPanel({ agent, onClose, onToggleStatus }: { agent: Agent, onClose: () => void, onToggleStatus: () => void }) {
  return (
    <>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
      />
      <motion.div 
        initial={{ x: 280 }}
        animate={{ x: 0 }}
        exit={{ x: 280 }}
        transition={{ type: "spring", stiffness: 250, damping: 25 }}
        className="fixed top-0 right-0 bottom-0 w-[280px] bg-surface-raised shadow-level-4 rounded-l-2xl z-50 flex flex-col border-l border-border-subtle"
      >
        <div className="p-comfortable flex flex-col h-full">
          <button 
            onClick={onClose}
            className="absolute top-comfortable right-comfortable p-1 text-text-tertiary hover:text-text-primary rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col items-center mt-stack-md mb-stack-md text-center">
            <img src={agent.avatar} alt={agent.name} className="w-20 h-20 rounded-full object-cover mb-snug shadow-md" />
            <h2 className="text-h2 tracking-tight text-text-primary">{agent.name}</h2>
            <span className="inline-flex items-center px-2 py-1 rounded text-caption font-medium bg-surface-base text-text-secondary mt-2 mb-4">
              {agent.role}
            </span>
            <div className="flex items-center gap-2">
              <StatusIndicator status={agent.status} />
              <span className="text-body text-text-secondary">{getStatusText(agent.status)}</span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-stack-md">
            <section>
              <h3 className="text-body font-semibold text-text-primary mb-snug">技能</h3>
              <ul className="space-y-1">
                {agent.skills.map((s, i) => (
                  <li key={i} className="text-body text-text-secondary flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-text-tertiary" />
                    {s}
                  </li>
                ))}
              </ul>
            </section>

            <section>
              <h3 className="text-body font-semibold text-text-primary mb-snug">任务历史</h3>
              <div className="space-y-2">
                {agent.history.length > 0 ? agent.history.map((h, i) => (
                  <div key={i} className="text-caption">
                    <div className="flex justify-between text-text-secondary mb-0.5">
                      <span>{h.date}</span>
                      <span className="text-text-tertiary">{h.status}</span>
                    </div>
                    <div className="text-text-primary truncate">{h.task}</div>
                  </div>
                )) : (
                  <div className="text-caption text-text-tertiary">暂无任务记录</div>
                )}
              </div>
            </section>
          </div>

          <div className="pt-comfortable mt-auto border-t border-border-subtle flex items-center justify-between">
            <span className="text-body font-medium text-text-primary">Agent 状态</span>
            <button 
              onClick={onToggleStatus}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${agent.status === 'running' ? 'bg-status-success' : 'bg-surface-base border border-border-strong'}`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${agent.status === 'running' ? 'translate-x-6' : 'translate-x-1 shadow-sm'}`} />
            </button>
          </div>
        </div>
      </motion.div>
    </>
  );
}

function StatusIndicator({ status }: { status: string }) {
  if (status === 'running') return <div className="w-2.5 h-2.5 rounded-full bg-status-success status-pulse shrink-0" />;
  if (status === 'error') return <div className="w-2.5 h-2.5 rounded-full bg-status-error shrink-0" />;
  return <div className="w-2.5 h-2.5 rounded-full bg-status-standby shrink-0" />;
}

function getStatusText(status: string) {
  if (status === 'running') return '运行中';
  if (status === 'error') return '错误';
  return '待命';
}