import { create } from 'zustand';

export interface Agent {
  id: string;
  name: string;
  role: string;
  status: 'running' | 'standby' | 'error';
  task: string;
  progress: number;
  colorClass: string;
  avatar: string;
  skills: string[];
  history: Array<{ date: string; task: string; status: string }>;
}

interface AgentsStore {
  agents: Agent[];
  selectedAgentId: string | null;
  selectAgent: (id: string | null) => void;
  toggleAgentStatus: (id: string) => void;
}

const defaultInitialState = {
  agents: [
    {
      id: 'a1',
      name: 'RA',
      role: '研究员',
      status: 'running' as const,
      task: '正在分析竞品报告',
      progress: 72,
      colorClass: 'bg-brand-primary',
      avatar: 'https://images.unsplash.com/photo-1645811791240-b45cc9534903?q=80&w=400',
      skills: ['数据采集', '报告生成', '竞品分析'],
      history: [
        { date: '2023-06-14', task: 'Q2市场调研', status: '已完成' },
        { date: '2023-06-10', task: '用户画像分析', status: '已完成' }
      ]
    },
    {
      id: 'a2',
      name: 'WA',
      role: '文案撰写',
      status: 'running' as const,
      task: '撰写产品介绍页文案',
      progress: 45,
      colorClass: 'bg-status-success',
      avatar: 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=400',
      skills: ['文案创作', 'SEO优化', '多语言翻译'],
      history: [
        { date: '2023-06-15', task: '官网落地页文案', status: '进行中' }
      ]
    },
    {
      id: 'a3',
      name: 'CR',
      role: '代码审查',
      status: 'standby' as const,
      task: '等待任务分配',
      progress: 0,
      colorClass: 'bg-purple-500',
      avatar: 'https://images.unsplash.com/photo-1635776063043-ab23b4c226f6?q=80&w=400',
      skills: ['代码审计', '安全扫描', '最佳实践检查'],
      history: [
        { date: '2023-06-12', task: 'API核心模块重构CR', status: '已完成' }
      ]
    },
    {
      id: 'a4',
      name: 'DA',
      role: '数据分析',
      status: 'running' as const,
      task: '处理用户行为数据集',
      progress: 88,
      colorClass: 'bg-status-warning',
      avatar: 'https://images.unsplash.com/photo-1710162734239-f2368bc6fae1?q=80&w=400',
      skills: ['数据清洗', '图表生成', '趋势预测'],
      history: []
    },
    {
      id: 'a5',
      name: 'DE',
      role: 'UI设计',
      status: 'error' as const,
      task: '任务超时，需要重试',
      progress: 30,
      colorClass: 'bg-status-error',
      avatar: 'https://images.unsplash.com/photo-1576502200916-3808e07386a5?q=80&w=400',
      skills: ['界面设计', '设计规范生成', '切图导出'],
      history: []
    },
    {
      id: 'a6',
      name: 'PL',
      role: '任务规划',
      status: 'standby' as const,
      task: '等待新周期开始',
      progress: 0,
      colorClass: 'bg-text-tertiary',
      avatar: 'https://images.unsplash.com/photo-1605106702842-01a887a31122?q=80&w=400',
      skills: ['任务拆解', '资源调度', '时间线规划'],
      history: []
    }
  ],
  selectedAgentId: null as string | null
};

export const useAgentsStore = create<AgentsStore>((set) => {
  // @ts-ignore
  const injectedState = window.App?.store?.agents || window.App?.store || {};
  return {
    ...defaultInitialState,
    ...injectedState,
    selectAgent: (id: string | null) => set({ selectedAgentId: id }),
    toggleAgentStatus: (id: string) => set((state) => ({
      agents: state.agents.map((a: Agent) => 
        a.id === id 
          ? { 
              ...a, 
              status: a.status === 'running' ? 'standby' : (a.status === 'error' ? 'standby' : 'running'), 
              progress: a.status === 'running' ? 0 : 10, 
              task: a.status === 'running' ? '已暂停' : (a.status === 'error' ? '已重置错误' : '已恢复运行') 
            }
          : a
      )
    }))
  };
});