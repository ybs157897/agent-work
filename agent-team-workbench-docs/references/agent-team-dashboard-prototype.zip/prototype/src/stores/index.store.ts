import { create } from 'zustand';

interface DashboardStore {
  activeAgentCount: number;
  runningTaskCount: number;
  todayCompletedCount: number;
  recentLogs: Array<{
    id: string;
    timestamp: string;
    agentName: string;
    action: string;
    status: 'success' | 'error' | 'running';
  }>;
  taskCounts: {
    todo: number;
    inProgress: number;
    completed: number;
    blocked: number;
  };
  miniAgents: Array<{
    id: string;
    name: string;
    role: string;
    status: 'running' | 'standby' | 'error';
    task: string;
    avatar: string;
  }>;
}

// Fallback initial data in case injection isn't present
const defaultInitialState = {
  activeAgentCount: 4,
  runningTaskCount: 6,
  todayCompletedCount: 9,
  recentLogs: [
    { id: '1', timestamp: '14:32:05', agentName: 'ResearchAgent', action: '完成竞品数据抓取', status: 'success' as const },
    { id: '2', timestamp: '14:28:10', agentName: 'DataAnalystAgent', action: '生成 Q3 增长报表', status: 'success' as const },
    { id: '3', timestamp: '14:15:22', agentName: 'DesignAgent', action: 'API 响应超时', status: 'error' as const },
    { id: '4', timestamp: '14:10:00', agentName: 'WriterAgent', action: '开始撰写产品文档', status: 'running' as const },
    { id: '5', timestamp: '13:45:11', agentName: 'CodeReviewAgent', action: '完成 PR #412 审查', status: 'success' as const },
    { id: '6', timestamp: '13:30:45', agentName: 'ResearchAgent', action: '开始用户访谈整理', status: 'running' as const },
  ],
  taskCounts: {
    todo: 3,
    inProgress: 3,
    completed: 3,
    blocked: 2,
  },
  miniAgents: [
    { id: 'a1', name: 'RA', role: '研究员', status: 'running' as const, task: '分析竞品报告', avatar: 'https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?q=80&w=400' },
    { id: 'a2', name: 'WA', role: '文案', status: 'running' as const, task: '撰写产品文档', avatar: 'https://images.unsplash.com/photo-1634618948828-aa7b3d0724fd?q=80&w=400' },
    { id: 'a3', name: 'DA', role: '数据', status: 'running' as const, task: '处理行为数据', avatar: 'https://images.unsplash.com/photo-1627037558426-c2d07beda3af?q=80&w=400' },
  ]
};

export const useDashboardStore = create<DashboardStore>((set) => {
  // @ts-ignore - Check if window.App exists for snapshot injection
  const injectedState = window.App?.store?.index || window.App?.store || {};
  return {
    ...defaultInitialState,
    ...injectedState
  };
});