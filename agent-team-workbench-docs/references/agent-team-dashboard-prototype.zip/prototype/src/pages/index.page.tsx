import React from 'react';
import { useDashboardStore } from '../stores/index.store';
import { LayoutShell } from '@components/layout-shell';
import { Bot, Zap, CheckCircle2, Circle, AlertCircle } from 'lucide-react';

export default function DashboardPage() {
  const activeAgentCount = useDashboardStore(s => s.activeAgentCount);
  const runningTaskCount = useDashboardStore(s => s.runningTaskCount);
  const todayCompletedCount = useDashboardStore(s => s.todayCompletedCount);
  const recentLogs = useDashboardStore(s => s.recentLogs);
  const taskCounts = useDashboardStore(s => s.taskCounts);
  const miniAgents = useDashboardStore(s => s.miniAgents);

  return (
    <LayoutShell breadcrumb="总览" activeNav="dashboard">
      <div className="layout-safe space-y-stack-md py-comfortable">
        
        {/* Welcome Section */}
        <section>
          <h1 className="text-h1 text-text-primary mb-tight tracking-tight">欢迎回来，Team</h1>
          <p className="text-body text-text-secondary">今天共有 {activeAgentCount} 个 Agent 在线运行</p>
        </section>

        {/* Stats Row */}
        <section className="grid grid-cols-3 gap-comfortable">
          <StatCard title="活跃 Agent 数" value={activeAgentCount} icon={<Bot className="w-5 h-5 text-brand-primary" />} />
          <StatCard title="运行中任务" value={runningTaskCount} icon={<Zap className="w-5 h-5 text-brand-accent" />} />
          <StatCard title="今日完成" value={todayCompletedCount} icon={<CheckCircle2 className="w-5 h-5 text-status-success" />} />
        </section>

        {/* Two-column Row */}
        <section className="grid grid-cols-3 gap-comfortable">
          
          {/* Agent Preview */}
          <div className="col-span-2 bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable">
            <h2 className="text-h3 text-text-primary mb-comfortable">Agent 状态速览</h2>
            <div className="flex gap-comfortable overflow-x-auto pb-2">
              {miniAgents.map(agent => (
                <div key={agent.id} className="flex items-center gap-snug p-snug rounded-lg border border-border-subtle shrink-0 w-64">
                  <img src={agent.avatar} alt={agent.name} className="w-10 h-10 rounded-full object-cover shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-semibold text-body truncate">{agent.name}</span>
                      <span className="text-caption text-text-tertiary">{agent.role}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <StatusDot status={agent.status} />
                      <span className="text-caption text-text-secondary truncate">{agent.task}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Task Snapshot */}
          <div className="col-span-1 bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable">
             <h2 className="text-h3 text-text-primary mb-comfortable">任务进度快照</h2>
             <div className="space-y-snug">
                <TaskStatRow label="待办" count={taskCounts.todo} color="bg-text-tertiary" />
                <TaskStatRow label="进行中" count={taskCounts.inProgress} color="bg-brand-accent" />
                <TaskStatRow label="完成" count={taskCounts.completed} color="bg-status-success" />
                <TaskStatRow label="阻塞" count={taskCounts.blocked} color="bg-status-error" />
             </div>
          </div>
        </section>

        {/* Logs Row */}
        <section className="bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable">
          <h2 className="text-h3 text-text-primary mb-comfortable">最近日志</h2>
          <div className="space-y-2">
            {recentLogs.map(log => (
              <div key={log.id} className="flex items-center gap-comfortable p-snug hover:bg-surface-base rounded-md transition-colors">
                <span className="text-caption text-text-tertiary tabular-nums shrink-0">{log.timestamp}</span>
                <div className="flex items-center gap-2 shrink-0 w-40">
                  {log.status === 'success' && <CheckCircle2 className="w-4 h-4 text-status-success" />}
                  {log.status === 'error' && <AlertCircle className="w-4 h-4 text-status-error" />}
                  {log.status === 'running' && <Circle className="w-4 h-4 text-brand-accent status-pulse" />}
                  <span className="font-medium text-body text-text-primary truncate">{log.agentName}</span>
                </div>
                <span className="text-body text-text-secondary truncate flex-1">{log.action}</span>
              </div>
            ))}
          </div>
        </section>

      </div>
    </LayoutShell>
  );
}

function StatCard({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) {
  return (
    <div className="bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable flex items-center justify-between">
      <div>
        <h3 className="text-body text-text-secondary mb-1">{title}</h3>
        <p className="text-display tracking-tight text-text-primary">{value}</p>
      </div>
      <div className="w-12 h-12 rounded-full bg-surface-base flex items-center justify-center shrink-0">
        {icon}
      </div>
    </div>
  );
}

function StatusDot({ status }: { status: string }) {
  if (status === 'running') return <div className="w-2 h-2 rounded-full bg-status-success status-pulse shrink-0" />;
  if (status === 'error') return <div className="w-2 h-2 rounded-full bg-status-error shrink-0" />;
  return <div className="w-2 h-2 rounded-full bg-status-standby shrink-0" />;
}

function TaskStatRow({ label, count, color }: { label: string, count: number, color: string }) {
  return (
    <div className="flex items-center justify-between p-2 rounded hover:bg-surface-base transition-colors">
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${color}`} />
        <span className="text-body text-text-secondary">{label}</span>
      </div>
      <span className="font-medium text-body text-text-primary tabular-nums">{count}</span>
    </div>
  );
}