# 视觉设计系统指南：融合亲和效能与空间呼吸 (A+C Fusion)

## 设计意图与哲学
本设计系统针对 AI 工程师和产品团队的日常协作监控，将清晰规整的“指挥舱”结构与灵动、有层次的空间呼吸感相结合。我们抛弃了厚重的工具感和冰冷的网格限制，采用温白至冷白的色温差异、柔和的层级阴影以及极微的半透明质感，塑造出一个轻盈且有生命力的 SaaS 仪表盘。

- **能量 (Energy)**: 安静专注，通过克制的强调色控制注意力，绝无刺眼的霓虹或过度的高对比度渐变。
- **质感 (Finish)**: 精致抛光 (Polished)，边缘柔和处理，应用微妙的磨砂玻璃效果，呈现高级且洁净的 UI 面板。
- **密度 (Density)**: 适中偏松弛。卡片和区块通过空间错落有致而非生硬的线条分割，信息排布紧凑但提供充分的留白呼吸。
- **重心 (Weight)**: 轻巧。由白及浅灰构建的主体结构搭配柔和过渡的蓝绿色系强调色。

## 排版系统与比例
本系统采用 `Minor Third` (1.200 比例) 缩放尺码，以 14px 基础字号搭建出高密度的信息架构，同时能够清晰区分从数据指示到微型标签的不同层级。

### 字体配置规则
- 英文衬线/无衬线体使用 **Google Fonts**。
  - Display/Headline: `Outfit` (几何感，带有科技呼吸感)
  - Body: `Inter` (极佳的效能易读性)
- 中文字体统一使用 **emfont** 获取。
  - 首选中文字体：`chironHeiHK` (现代利落的黑体，比传统默认字体更显精致并具独立调性)。避免使用系统预设黑体直接作为首选，以防产生 AI 生成感。

## 颜色规范与约束
### 色温与质感
- **背景层**: 不使用单一死板的白色或冷灰，而是利用基础色温 `#F8FAFC`（略带极轻微的冷白基调）作为深远底色。
- **卡片层**: 高于背景的纯白卡片结合层级阴影形成空间断层。在深色模式下，严禁出现发紫或赛博朋克风的色调，改用纯粹的中性暗灰（Zinc色系）来维持高级的工具感。
- **强调色 (Accent)**: 从常规 SaaS 工具泛用的经典蓝跳出，采用 `0EA5E9` 到 `0284C7` (天蓝至生命力蓝绿) 范围内的克制蓝绿色，避免使用亮瞎眼的青色（Cyan）或紫色搭配。

### 严禁使用的颜色模式 (Anti-Patterns)
1. **绝不使用** 紫色或紫蓝搭配作为强调色。
2. **绝不使用** 高饱和粉-青 (Pink-Cyan) 渐变。
3. **绝不使用** 任何带霓虹荧光发光效果的元素。
4. **绝不使用** 纯灰/沉闷的土色覆盖整个界面（必须包含冷暖对比）。

## 组件实现配方 (Tailwind v3.4)

### 1. 容器与卡片 (Surface & Cards)
展现空间断层和极轻微的磨砂半透明质感。
```html
<!-- Base Card (Level 1) -->
<div class="bg-surface-raised rounded-card shadow-level-1 border border-border-subtle p-comfortable">
  <!-- Content -->
</div>

<!-- Floating Glass Panel (Level 2) -->
<div class="bg-surface-glass backdrop-blur-md rounded-card shadow-level-2 border border-white/20 p-comfortable">
  <!-- Content -->
</div>
```

### 2. 交互按钮 (Interactive Buttons)
必须含有基于真实触感和状态的反馈。
```html
<!-- Primary Button -->
<button class="bg-brand-primary text-white rounded-button px-base py-tight font-body-lg font-medium transition-all duration-150 ease-out hover:bg-brand-accent hover:-translate-y-px hover:shadow-level-1 active:scale-[0.98] active:shadow-none disabled:opacity-50 disabled:cursor-not-allowed">
  分配任务
</button>

<!-- Secondary Outline Button -->
<button class="bg-transparent border border-brand-primary text-brand-primary rounded-button px-base py-tight font-medium transition-colors duration-150 ease-out hover:bg-brand-primary/5 active:scale-[0.98]">
  查看日志
</button>
```

### 3. 左侧极简图标导航项 (Minimal Icon Nav Item)
保持贴近参考图 A 的左侧留白导航，选中状态用蓝色块。
```html
<!-- Default Nav Item -->
<button class="w-10 h-10 flex items-center justify-center rounded-button text-text-muted transition-colors duration-200 hover:text-text-primary hover:bg-surface-base">
  <svg class="w-5 h-5" ...></svg>
</button>

<!-- Active Nav Item -->
<button class="w-10 h-10 flex items-center justify-center rounded-button text-white bg-brand-primary shadow-level-1 transition-transform active:scale-[0.95]">
  <svg class="w-5 h-5" ...></svg>
</button>
```

### 4. 任务拖拽看板标签 (Kanban Label)
```html
<span class="inline-flex items-center px-2 py-1 rounded-sm text-caption font-medium bg-brand-primary/10 text-brand-accent border border-brand-primary/20">
  Agent 指派
</span>
```

## 动效物理规范 (Motion Physics)
本系统的动效应遵循以下物理特性，传递“磁吸与漂浮”的空间特质。

### 1. 点击反馈 (Click & Tactile)
所有按钮必须有物理按压感。
```css
/* Button Press - 快速反馈，无阻力卡入 */
scale: 0.98;
transition: transform 50ms ease-out;
```

### 2. 卡片悬浮 (Hover Float)
卡片悬浮时有微幅的上升，表现失重与激活。
```css
/* Hover Lift - 轻微上浮，带一定重量感 */
transform: translateY(-3px);
box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05); /* 阴影扩展表现高度 */
transition: all 250ms ease-out; /* 属于 Standard duration */
```

### 3. 面板与抽屉滑出 (Drawer Slide)
 Agent 详情侧面板拉出时的运动。
```css
/* Slide In - 如同气压关门器般平滑，带有良好的阻尼感 */
transform: translateX(0);
transition: transform 300ms ease-out;
```

**动效测试闸门**: 确保动效只在用户交互或关键引导时触发。严禁使用随意的页面滚动淡入（Scroll Fade-in）和跟随鼠标移动的特效（Cursor tracking）。

## 质量审核控制网 (Design Audit Gates)
上线前的内部视觉质量自测标准：
1. **无紫黑深色背景**：界面中不得出现 #0D0B1A 或带有紫色色偏的极暗色彩。
2. **纯粹的强调色**：按钮与进度条的蓝色带有清晰的绿相倾向 (天蓝/蓝绿)，而非混入紫色的妖艳渐变。
3. **真实的信息填充**：所有表单、列表和卡片的数据展现需如同真实运行状态（禁止出现 Lorem ipsum, 用户名一律使用多元化全称而非 John Doe）。
4. **响应式架构**：看板在缩小时列宽度保持最小值并出现水平滚动，以保证卡片上 Agent 状态展示的文本不会溢出。
5. **焦距与层级**：阴影的过度和不同面板色温差异明确指向可拖拽的独立层。
