import { create } from 'zustand';

export interface Task {
  id: string;
  title: string;
  priority: 'high' | 'medium' | 'low';
  agentName: string | null;
  agentAvatar: string | null;
  agentColor: string | null;
  dueDate: string;
  status: 'todo' | 'inProgress' | 'completed' | 'blocked';
  blockedReason?: string;
}

interface TasksStore {
  tasks: Task[];
  viewMode: 'kanban' | 'list';
  setViewMode: (m: 'kanban' | 'list') => void;
}

const defaultInitialState = {
  viewMode: 'kanban' as const,
  tasks: [
    // Todo
    { id: 't1', title: '竞品调研报告', priority: 'high' as const, status: 'todo' as const, agentName: null, agentAvatar: null, agentColor: null, dueDate: '06/15' },
    { id: 't2', title: '落地页文案优化', priority: 'medium' as const, status: 'todo' as const, agentName: null, agentAvatar: null, agentColor: null, dueDate: '06/18' },
    { id: 't3', title: '数据看板需求文档', priority: 'low' as const, status: 'todo' as const, agentName: null, agentAvatar: null, agentColor: null, dueDate: '06/22' },
    // In Progress
    { id: 't4', title: '用户访谈整理', priority: 'high' as const, status: 'inProgress' as const, agentName: 'ResearchAgent', agentAvatar: 'https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?q=80&w=400', agentColor: 'bg-brand-primary', dueDate: '06/12' },
    { id: 't5', title: 'Q3增长策略分析', priority: 'high' as const, status: 'inProgress' as const, agentName: 'DataAnalystAgent', agentAvatar: 'https://images.unsplash.com/photo-1710162734239-f2368bc6fae1?q=80&w=400', agentColor: 'bg-status-warning', dueDate: '06/14' },
    { id: 't6', title: '首页重设计', priority: 'medium' as const, status: 'inProgress' as const, agentName: 'DesignAgent', agentAvatar: 'https://images.unsplash.com/photo-1576502200916-3808e07386a5?q=80&w=400', agentColor: 'bg-status-error', dueDate: '06/16' },
    // Completed
    { id: 't7', title: 'API文档编写', priority: 'medium' as const, status: 'completed' as const, agentName: 'CodeReviewAgent', agentAvatar: 'https://images.unsplash.com/photo-1635776063043-ab23b4c226f6?q=80&w=400', agentColor: 'bg-purple-500', dueDate: '06/10' },
    { id: 't8', title: '品牌色板确认', priority: 'low' as const, status: 'completed' as const, agentName: 'DesignAgent', agentAvatar: 'https://images.unsplash.com/photo-1576502200916-3808e07386a5?q=80&w=400', agentColor: 'bg-status-error', dueDate: '06/09' },
    { id: 't9', title: '用户旅程地图', priority: 'medium' as const, status: 'completed' as const, agentName: 'ResearchAgent', agentAvatar: 'https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?q=80&w=400', agentColor: 'bg-brand-primary', dueDate: '06/08' },
    // Blocked
    { id: 't10', title: '竞品数据采集', priority: 'high' as const, status: 'blocked' as const, agentName: null, agentAvatar: null, agentColor: null, dueDate: '06/15', blockedReason: '缺少权限' },
    { id: 't11', title: '视觉规范审批', priority: 'medium' as const, status: 'blocked' as const, agentName: null, agentAvatar: null, agentColor: null, dueDate: '06/16', blockedReason: '等待反馈' },
  ]
};

export const useTasksStore = create<TasksStore>((set) => {
  // @ts-ignore
  const injectedState = window.App?.store?.tasks || window.App?.store || {};
  return {
    ...defaultInitialState,
    ...injectedState,
    setViewMode: (m: 'kanban' | 'list') => set({ viewMode: m })
  };
});